ruby $1/nagMailACK.rb &
